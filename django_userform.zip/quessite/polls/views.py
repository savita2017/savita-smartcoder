from django.shortcuts import render,get_object_or_404,render_to_response
from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse
from django.views import generic
from django.template import loader
from django.utils import timezone
from django.contrib.auth import authenticate,login,logout
from .models import Question,Choice,User
from .forms import UserForm
from django.contrib.auth.decorators import login_required

def index(request):
    return render(request,'polls/index.html')    
        
#login part---when user login
#@login_required
def special(request):
    return HttpResponse("Logged")

#----when user logout
#@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))

def register(request):
    registered=False
    if request.method =='POST':
        user_form=UserForm(data=request.POST)
        if user_form.is_valid():
            user=user_form.save()
            user.set_password(user.password)
            user.save()
            #reverse('polls:results',args=(question_id,
            #return render(request,'polls/registeration.html',{'user_form':user_form})
            registered=True
            #return HttpResponse("You are registered now")
            #return HttpResponseRedirect(reverse('index'))
            return render(request,'polls/login.html',{})
        else:
            print(user_form.errors)
            return HttpResponse("Invalid details")
    else:
        user_form=UserForm()
        return render(request,'polls/registeration.html',{'user_form':user_form})

def user_login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(username=username,password=password)
        if user:
            if user.is_active:
                login(request,user)
                return HttpResponseRedirect(reverse('index'))
            else:
                return HttpResponse("User inactive")
        else:
            print("You are not registered user")
            print("You enter username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid details")
    else:
        return render(request,'polls/login.html',{})

      
class IndexView(generic.ListView):
    template_name = 'polls/index.html'
    context_object_name = 'latest_question_list'

    def get_queryset(self):
        """Return the last five published questions."""
        #return Question.objects.order_by('-pub_date')[:5]
        return Question.objects.filter(
        pub_date__lte=timezone.now()
        ).order_by('-pub_date')[:5]

class DetailView(generic.DetailView):
    model = Question
    template_name = 'polls/detail.html'
    
    def get_queryset(self):
        """
        Excludes any questions that aren't published yet.
        """
        return Question.objects.filter(pub_date__lte=timezone.now())

class ResultsView(generic.DetailView):
    model = Question
    template_name = 'polls/results.html'




def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    if request.method=='POST':
        if 'choice' in request.POST:
            selected_choice = question.choice_set.get(pk=request.POST['choice'])
            selected_choice.votes += 1
            selected_choice.save()
            return HttpResponseRedirect(reverse('polls:results',args=(question_id,)))
        else:
            return render(request, 'polls/detail.html', {'question': question, 'error_message': "Please select a choice "})
    return render(request,'polls/detail.html', {'question': question})
    # And here is the checking happens.
    voters = [user.id for user in Voter.objects.filter(poll__id=poll_id)]
    if request.user.id in voting:
        return render(request, 'polls/detail.html', {
        'poll': p,
        'error_message': "Sorry, but you have already voted."
        })
    try:
        selected_choice = p.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the poll voting form.
        return render(request, 'polls/detail.html', {
        'poll': p,
        'error_message': "You didn't select a choice."
        })
    else:
        selected_choice.votes +=1
        selected_choice.save()
        v = Voter(user=request.user, poll=p)
        v.save()
        return HttpResponseRedirect(reverse('polls:results', args=(p.id,)))






