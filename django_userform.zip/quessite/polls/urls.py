from django.urls import path
from .import views
from django.conf.urls import url



# url(r'^register/$',views.register,name='register'),
# url(r'^user_login/$',views.user_login,name='user_login'),


#Namespacing of app poll
app_name='polls'

urlpatterns=[
    url(r'^registeration/$',views.register,name='registeration'),
    url(r'^user_login/$',views.user_login,name='user_login'),
    path('', views.IndexView.as_view(), name='index'),
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    path('<int:pk>/results/', views.ResultsView.as_view(), name='results'),
    path('<int:question_id>/vote/', views.vote, name='vote'),
]